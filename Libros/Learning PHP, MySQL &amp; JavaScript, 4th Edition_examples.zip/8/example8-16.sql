SELECT author,title FROM classics;
SELECT title,isbn FROM classics;
