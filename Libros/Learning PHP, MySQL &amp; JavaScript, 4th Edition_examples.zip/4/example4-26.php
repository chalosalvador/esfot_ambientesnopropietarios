<?php
  echo $fuel <= 1 ? "Fill tank now" : "There's enough fuel";
?>
