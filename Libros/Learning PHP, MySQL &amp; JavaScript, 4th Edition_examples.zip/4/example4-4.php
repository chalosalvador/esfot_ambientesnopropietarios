<?php
  $day_number       = 340;                // Assignment by Value
  $days_to_new_year = 366 - $day_number;  // Assignment by Expression

  if ($days_to_new_year < 30)             // Condition
  {
    echo "Not long now till new year";    // Statement
  }
?>
