setInterval(function ()
{
  O('clock').innerHTML = new Date()
}, 1000)
